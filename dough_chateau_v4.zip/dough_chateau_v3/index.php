<!doctype html>
<html lang="en">
<head>

    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Chateau Dough</title>
    <link type="text/css" rel="stylesheet" href="css/styles.css"/>
</head>

<body style="background-image: url('img/heroimg.jpg'); background-size: cover;">
<?php
require ('includes/header.php');
?>



<div class="wrapper">
<header>
    <p class="header1"> Vegan sweets fit for <p> <p class="header2"> royalty <p>
</header>

</div>


</body>
</html>
<?php
include ('includes/footer.php');