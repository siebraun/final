<!doctype html>
<html lang="en">
<head>

    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Chateau Dough</title>
    <link type="text/css" rel="stylesheet" href="css/styles.css"/>
</head>

<div id="navbar">
    <img style="width: 5%; float: left;" src="img/chateau_dough_logo1.PNG" alt="Chateau Dough">
    <h1 class="logoText" style="float: left;"> CHATEAU DOUGH </h1>
    <a class="shoppingCart" href="showcart.php"><img src='img/shoppingcart.png' alt='Shopping cart'
                                                     style='width: 40px; border: none'></a>
    <a class="navText" href="index.php">Home </a>
    <a class="navText" href="products.php">Our Pastries</a>
    <a class="navText" href="allergens.php">Allergens</a>
    <a class="navText" href="login.php">Log In</a>
</div>
