<?php
require 'includes/header.php';
require_once 'includes/database.php';

$sql = "SELECT * FROM products";


$query = $conn->query($sql);

if (!$query) {
    $errno = $conn->errno;
    $errmsg = $conn->error;
    echo "Selection failed with: ($errno) $errmsg<br/>\n";
    $conn->close();
    require_once('includes/footer.php');
    exit;
}

?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Allergens</title>
    <link type="text/css" rel="stylesheet" href="www/chateaudough.css" />
</head>
<body>
<!-- navigation bar -->
<div id="navbar">
    <a href="index.php">Home</a> || <a href="products.php">Our Pastries</a> || <a href="allergens.php">Allergens</a>
    || <a href="login.php">Log In</a>
</div>
<div class="allergenTableDiv">
    <table id="allergenTableBig" class="allergenTableBig">
        <tr>
            <th>Item</th>
            <th class="col2">Allergens</th>
            <!--
            <th class="col2">Peanuts</th>
            <th class="col3">Tree Nuts</th>
            <th class="col4">Dairy</th>
            <th class="col5">Wheat</th>
            <th class="col6">Eggs</th>
            <th class="col7">Soy</th>
            <th class="col8">Sesame</th>
            <th class="col8">Gluten</th>
            --!>
        </tr>
        <!-- add PHP code here to list all books from the "books" table -->
        <?php
        while (($row = $query->fetch_assoc()) !== NULL) {
            echo "<tr>";

            echo "<td><a href='bookdetails.php?id=", $row["product_id"], "'>", $row['product_name'],"</a></td>";
            echo "<td>", $row['allergens'], "</td>";
        }
        ?>
    </table>
</div>
</body>
</html>