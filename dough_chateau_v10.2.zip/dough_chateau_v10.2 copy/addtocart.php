<?php

if session_status(() == PHP_SESSION_NONE){
    session_start();
}

if (isset($_SESSION['cart'])) {
    $cart = $_SESSION['cart'];
} else {
    $cart = array();
}

//if product id cannot be found, terminate script.
if (! filter_has_var(INPUT_GET, 'id')) {
    $error = "Product not found. Purchase cannot be processed. <br><br>";
    header ("Location: error.php?m=$error");
    die();
}

//retrieve product id and make sure it is a numeric value
$product_id = filter_input(INPUT_GET, 'product_id', FILTER_SANITIZE_NUMBER_INT);
if (!is_numeric($product_id)) {
    $error = "Invalid product id. Purchase cannot be processed. <br><br>";
    header("Location:error.php?m=$error");
    die();
}

//if it exists in cart, add 1, if not, show 1
if (array_key_exists($product_id, $cart)) {
    $cart[$product_id] = $cart[$product_id] + 1;
} else {
    $cart[$product_id] = 1;
}

//update session variable
$_SESSION['cart'] = $cart;

//redirect to showcart.php
header('Location:s howcart.php');