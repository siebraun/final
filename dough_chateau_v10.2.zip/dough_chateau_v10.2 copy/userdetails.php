<?php


$page_title = "Users Details";

require_once ('includes/header.php');
require_once ('includes/database.php');

$user_id = filter_input(INPUT_GET, 'id', FILTER_SANITIZE_NUMBER_INT);
$sql = "SELECT * FROM users WHERE id=$user_id";

//execute query
$query = $conn->query($sql);
//retrieve results
$row = $query->fetch_assoc();



//Handle selection errors
if (!$query) {
    $errno = $conn->errno;
    $errmsg = $conn->error;
    echo "Selection failed with: ($errno) $errmsg<br/>\n";
    $conn->close();
    //include the footer
    require_once ('includes/header.php');
    exit;
}
//display results in a table in the below HTML block
?>

    <h2>User Details</h2>

    <table class="userlist">
        <tr>
            <th>Username</th>
            <td> <?php echo $row['username'] ?> </td>
        </tr>
        <tr>
            <th>Email</th>
            <td> <?php echo $row['email'] ?> </td>
        </tr>
        <tr>
            <th>Password</th>
            <td> <?php echo $row['password'] ?> </td>
        </tr>

    </table>
    <p>  <a href="edituser.php?id=<?php echo $row['id'] ?>">Edit</a>
        <a href="deleteuser.php?id=<?php echo $row['id'] ?>">Delete</a>
        <a href="listusers.php">Cancel</a>  </p>

    <p><a href="listusers.php">Back to Users</a></p>

<?php
// clean up resultsets when we're done with them!
$query->close();

// close the connection.
$conn->close();

//include the footer
require_once ('includes/footer.php');
?>