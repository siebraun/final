<?php
//this is the search results page that Sophia made
require_once 'includes/database.php';
require_once ('includes/header.php');

//connect to MySQL
$conn = @new mysqli($host,$login, $password, $database);

//get and sanitize??
if (filter_has_var(INPUT_GET, "terms")) {
    $terms_str = filter_input(INPUT_GET, 'terms', FILTER_SANITIZE_STRING);
} else {
    echo "There was not search terms found.";
    include ('includes/footer.php');
    exit;
}

//search query
$query = "SELECT * FROM products WHERE product_id LIKE '%" . $search . "%'";
$result = $mysqli->query($query) or die($mysqli->error.__LINE__);


// searching through data
if($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        echo $row['product_name'];
    }
}

else {
    echo 'NO RESULTS';
}

//handle connection errors
if ($con-> connect_errorno){
    $errno = $conn->connect_errno;
    $errmsg - $conn ->connect_error;
    die ("Connection to database failed: ($errno) $errmsg.");
}

// close connection
mysqli_close($mysqli);

//specifically need help linking the query to the search bar
