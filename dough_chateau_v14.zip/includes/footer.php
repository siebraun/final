
</div>
<div id="footer">
    <hr width="95%" />
    &copy <?php echo date("Y") ?> Dough Chateau Online Bakery. All Rights Reserved.
</div>
</div>

</body>
</html>