<?php

$page_title = "PHP Online Bookstore Login";
require_once('includes/header.php');
?>

<?php
$message = "Please enter your username and password to login.";

//check the login status
$login_status = '';
if (isset($_SESSION['login_status']))
    $login_status = $_SESSION['login_status'];

//user logged in
if ($login_status == 1) {
    echo "<p style='font: 30px Lato, Sans-serif; color: #ac7197;  '>You are logged in.</p>";
    echo "<a style='font: 20px Lato, Sans-serif; color: #FFFFFF;  padding: 10px; background-color: #e3b8d4;' href = 'logout.php'> Logout </a><br/>";
    include('includes/footer.php');
    exit();
}

//user registered
if ($login_status == 3) {
    echo "<p style='font: 28px Lato, Sans-serif; color: #ac7197;' >Your account has been created.</p>";
    echo "<a href='logout.php'>Logout</a><br/>";
    include('includes/footer.php');
    exit();
}

//invalid data
if ($login_status == 2) {
    $message = "Username or password invalid. Please try again.";
}


?>
    <div class="login-container">
        <!-- display the login form -->
        <div class="row">
            <div class="column">
                <div class="login">
                    <form method='post' action='login.php'>
                        <table>
                            <tr>
                                <td style="font: 20px Lato, Sans-serif" colspan="2"><?php echo $message; ?><br><br></td>
                            </tr>
                            <tr>
                                <td style="width: 80px">User name:</td>
                                <td><input type='text' name='username' required></td>
                            </tr>
                            <tr>
                                <td>Password:</td>
                                <td><input type='password' name='password' required></td>
                            </tr>
                            <tr>
                                <td colspan='2' style='padding: 10px 0 0 85px' class="bookstore-button">
                                    <input type='submit' value='  Login  '>
                                    <input type="submit" name="Cancel" value="Cancel"
                                           onclick="window.location.href = 'index.php'"/>
                                </td>
                            </tr>
                        </table>
                    </form>
                </div>
            </div>

            <br>

            <!-- display the registration form -->
            <div class="column">
                <div class="registration">
                    <form action="register.php" method="post">
                        <table>
                            <tr>
                                <td style="font: 20px Lato, Sans-serif" colspan="2" align="left">If you are new to our site, please create an
                                    account.<br><br></td>
                            </tr>
                            <tr>
                                <td style="width: 85px">First Name:</td>
                                <td><input name="firstname" type="text" required></td>
                            </tr>
                            <tr>
                                <td>Last Name:</td>
                                <td><input name="lastname" type="text" required></td>
                            </tr>
                            <tr>
                                <td>User Name:</td>
                                <td><input name="username" type="text" required></td>
                            </tr>
                            <tr>
                                <td>Password:</td>
                                <td><input name="password" type="password" required></td>
                            </tr>
                            <tr>
                                <td colspan="2" style='padding: 10px 0 0 80px' class="bookstore-button">
                                    <input type="submit" value="Register"/>
                                    <input type="button" value="Cancel"
                                           onclick="window.location.href = 'index.php'"/>
                                </td>
                            </tr>
                        </table>

                    </form>
                </div>
            </div>
        </div>
    </div>

<?php
include('includes/footer.php');
