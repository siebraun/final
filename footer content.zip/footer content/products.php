<?php
require 'includes/header.php';
require_once 'includes/database.php';

$sql = "SELECT * FROM products";

//execute the query
$query = $conn->query($sql);

//retrieve results
$row = $query->fetch_assoc();


if (!$query) {
    $errno = $conn->errno;
    $errmsg = $conn->error;
    echo "Selection failed with: ($errno) $errmsg<br/>\n";
    $conn->close();
    require_once('includes/footer.php');
    exit;

    $result = $conn->query($sql) or die($conn->error);
}
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Products</title>
    <link type="text/css" rel="stylesheet" href="www/chateaudough.css" />
</head>





<body>
<!-- navigation bar -->
<div id="navbar">
    <a href="index.php">Home</a> || <a href="products.php">Our Pastries</a> || <a href="allergens.php">Allergens</a>
    || <a href="login.php">Log In</a>
</div>

<!-- body -->

<div style="width: 80%" class="allergenTableDiv">
    <table id="allergenTableBig" class="allergenTableBig">
    <tr>
        <th></th>
        <th class="col2"></th>
        <th class="col3"></th>
        <th class="col4"></th>
        <th class="col5"></th>
        <th class="col6"></th>
        <th class="col7"></th>
    </tr>

    <!-- book data -->
    <?php
    while(($row = $query->fetch_assoc()) !==NULL){
        echo "<tr>"; ?>

        <td> <img width="100px" src=" <?php echo $row['image']?>"/> </td>
<?php   echo "<td><a href=product_details.php?id=", $row["product_id"], ">", $row["product_name"], "</a></td>";
        echo "<td>", $row['price'], "</td>";
    }
    ?>
    </table>
</div>


</body>
</html>
<?php
include ('includes/footer.php');