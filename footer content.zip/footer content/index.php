<!doctype html>
<html lang="en">
<head>

    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Chateau Dough</title>
    <link type="text/css" rel="stylesheet" href="www/chateaudough.css"/>
</head>

<body>
<?include ('includes/header.php');
?>
<header>
    <!-- navigation bar -->
<div id="navbar">
        <a href="index.php">Home</a> || <a href="products.php">Our Pastries</a> || <a href="allergens.php">Allergens</a>
        || <a href="login.php">Log In</a> || <a href="showcart.php"><img src='img/shoppingcart.png' alt='Shopping cart'
                                                                         style='width: 50px; border: none'></a>
</div>

    <table id="banner">
      <tr>
          <td>
              <img src="img/chateau_dough_logo1.PNG" alt="Chateau Dough">
          </td>
          <td>
              <div id="maintitle">Chateau Dough</div>
              <div id="subtitle">Vegan sweets fit for royalty</div>
          </td>
      </tr>
</table>
</header>
<p>Chateau Dough Pastries</p> <br>
<p>More content</p>
</body>
</html>
<?php
include ('includes/footer.php');