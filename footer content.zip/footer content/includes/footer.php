</div>
<div id="footer">
    <hr width="90%" />
    &copy <?php echo date("Y") ?> Chateau Dough Inc. All Rights Reserved.
</div>
</div>
</body>
</html>