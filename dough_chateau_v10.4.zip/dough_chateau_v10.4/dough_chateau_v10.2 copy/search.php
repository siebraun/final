
<?php

//connect to database
$host = "localhost";
$login = //??
$password = //what account would be put here?
$database = "dough_chateau";

//connect to MySQL
$conn = @new mysqli($host,$login, $password, $database);

//search query
$query = "SELECT * FROM products WHERE product_id LIKE '%" . $search . "%'";
$result = $mysqli->query($query) or die($mysqli->error.__LINE__);


// searching through data
if($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        echo $row['product_name']);
    }
}

else {
    echo 'NO RESULTS';
}

//handle connection errors
if ($con-> connect_errorno){
    $errno = $conn->connect_errno;
    $errmsg - $conn ->connect_error;
    die ("Connection to database failed: ($errno) $errmsg.");
}

// close connection
mysqli_close($mysqli)

//specifically need help linking the query to the search bar
