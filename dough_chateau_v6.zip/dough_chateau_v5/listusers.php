<?php

$page_title = "List users";

require_once ('includes/header.php');
require_once ('includes/database.php');

$sql = "SELECT * FROM users";

//execute query
$query = $conn->query($sql);

//Handle selection errors
if (!$query) {
    $errno = $conn->errno;
    $errmsg = $conn->error;
    echo "Selection failed with: ($errno) $errmsg<br/>\n";
    $conn->close();
    require_once('includes/footer.php');
    exit();
}
?>


    <!--display results in a table-->
    <h2>Users</h2>

    <table class="userlist">
        <tr>
            <th>Username</th>
            <th>Email</th>
            <th>Password</th>
        </tr>

        <!-- user data -->
        <?php
        while(($row = $query->fetch_assoc()) !==NULL){
            echo "<tr>";
            echo "<td><a href=userdetails.php?id=", $row["id"], ">", $row['username'],"</a></td>";
            echo "<td>", $row['email'], "</td>";
            echo "<td>", $row['password'], "</td>";
        }
        ?>
    </table>

<?php
// clean up resultsets when we're done with them!
$query->close();

// close the connection.
$conn->close();

//include the footer
require_once ('includes/footer.php');