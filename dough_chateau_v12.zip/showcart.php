<?php
$page_title = "Shopping Cart";
require_once('includes/header.php');
require_once('includes/database.php');
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <title>Shopping Cart</title>
</head>
<body>
<p>Check out</p>

<?php
if (! isset($_SESSION['cart']) || ! $_SESSION['cart']) {
    echo "Your shopping cart is empty.<br><br>";
    include('includes/footer.php');
    exit();
}

//proceed since the cart is not empty
$cart = $_SESSION['cart'];
//print_r($cart);
?>
<table class="productlist">
    <tr>
        <th style="width: 500px">Product</th>
        <th style="width: 60px">Price</th>
        <th style="width: 60px">Quantity</th>
        <th style="width: 60px">Total</th>
    </tr>
    <?php
    //insert code to display the shopping cart content
//    if (! filter_has_var(INPUT_GET, 'id')){
//        echo "error: product id was not found.";
//        exit();
//    }
//    $product_id = filter_input(INPUT_GET, 'id', FILTER_SANITIZE_NUMBER_INT);

    //select statement
    $sql="SELECT product_id, product_name, price FROM products WHERE 0 ";
    foreach(array_keys($cart) as $product_id){
        $sql.=" OR product_id=$product_id ";
    }

    //echo $sql;

    $query = $conn->query($sql);

    //fetchbooksanddisplaytheminatable
    while ($row = $query->fetch_assoc()){
        $product_id= $row['product_id'];
        $product_name=$row['product_name'];
        $price=$row['price'];
        $qty=$cart[$product_id];
        $total= $qty * $price;
        echo"<tr>",
        "<td><a href='product_details.php?id=$product_id'>$product_name</a></td>",
        "<td>$$price</td>",
        "<td>$qty</td>",
        "<td>$$total</td>",
        "<tr>";

    }

//    $sql="SELECT product_id, product_name, price FROM products WHERE 0";
//    foreach(array_keys($cart) as $product_id){
//        $sql.=" OR id=$product_id ";
//    }

    //execute the query
    $query = @$conn->query($sql);

//    //fetchbooksanddisplaytheminatable
//    while ($row = $query->fetch_assoc()){
//        $product_id= $row['id'];
//        $product_name=$row['product_name'];
//        $price=$row['price'];
//        $qty=$cart[$product_id];
//        $total= $qty * $price;
//        echo"<tr>",
//        "<td><a href='product_details.php?id=$product_id'>$product_name</a></td>",
//        "<td>$$price</td>",
//        "<td>$qty</td>",
//        "<td>$$total</td>",
//        "<tr>";
//
//    }

    ?>
</table>
<br>
<div class="bookstore-button">
    <input type="button" value="Checkout" onclick="window.location.href = 'checkout.php'"/>
    <input type="button" value="Cancel" onclick="window.location.href = 'products.php'" />
</div>
<br><br>

<br> <p>Until Next Time!</p>
</body>

<?php require ('includes/footer.php') ?>
</html>