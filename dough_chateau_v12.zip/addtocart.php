<?php
require('includes/database.php');
require('includes/header.php');

if(session_status()==PHP_SESSION_NONE){session_start();}

if (isset($_SESSION['cart'])) {
    $cart = $_SESSION['cart'];
} else {
    $cart = array();
}

//print_r($cart);

//retrieve product id
if (! filter_has_var(INPUT_GET, 'id')){
    echo "error: product id was not found.";
    exit();
}
$product_id = filter_input(INPUT_GET, 'id', FILTER_SANITIZE_NUMBER_INT);

if(!is_numeric($product_id)) {
    $error = "Invalid product id. Purchase cannot be processed. <br><br>";
    header("Location:error.php?m=$error");
    die();
}

//$sql = "SELECT * FROM products WHERE product_id=$product_id";
//
//echo $sql;
//
//$query = $conn->query($sql);

//if product id cannot be found, terminate script.
//if(! filter_has_var(INPUT_GET,'id')){
//    $error="Product ID not found.<br><br>";
//    header("Location:error.php?m=$error");
//    die();
//}

//retrieve product id and make sure it is a numeric value
//$product_id = filter_input(INPUT_GET, 'id', FILTER_SANITIZE_NUMBER_INT);

//if it exists in cart, add 1, if not, show 1
if (array_key_exists($product_id, $cart)) {
    $cart[$product_id] = $cart[$product_id] + 1;
} else {
    $cart[$product_id] = 1;
}

//update session variable
$_SESSION['cart'] = $cart;

//redirect to showcart.php
header('Location: showcart.php');