<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8"/>
    <title>Add a new product</title>
    <link rel="stylesheet" href="css/styles.css"/>
</head>
<body>
<?php
require('includes/database.php');
require('includes/header.php');
// When form submitted, insert values into the database.
if (isset($_REQUEST['product_name'])) {
    // removes backslashes
    $product_name = stripslashes($_REQUEST['product_name']);
    //escapes special characters in a string
    $product_name = mysqli_real_escape_string($conn, $product_name);
    $price    = stripslashes($_REQUEST['price']);
    $price    = mysqli_real_escape_string($conn, $price);
    $allergens = stripslashes($_REQUEST['allergens']);
    $allergens = mysqli_real_escape_string($conn, $allergens);
    $description = stripslashes($_REQUEST['description']);
    $description = mysqli_real_escape_string($conn, $description);
    $product_img = stripslashes($_REQUEST['product_img']);
    $product_img = mysqli_real_escape_string($conn, $product_img);
    $query    = "INSERT into `products` (product_name, allergens, price, description, product_img)
                     VALUES ('$product_name', '" . ($allergens) . "', '$price', '$description', '$product_img')";
    $result   = mysqli_query($conn, $query);
    if ($result) {
        echo "<div class='form'>
                  <h3>You are added a product successfully.</h3><br/>
                  <p class='link'>Click here to <a href='products.php'>return</a></p>
                  </div>";
    } else {
        echo "<div class='form'>
                  <h3>Required fields are missing.</h3><br/>
                  <p class='link'>Click here to <a href='newproduct.php'>try again</a> again.</p>
                  </div>";
    }
} else {
    ?>
    <form class="form" action="" method="post">
        <h1 class="login-title">Add a product</h1>
        <input type="text" class="login-input" name="product_name" placeholder="Product Name" required />
        <input type="text" class="login-input" name="price" placeholder="Price">
        <input type="text" class="login-input" name="allergens" placeholder="Allergens">
        <input type="text" class="login-input" name="description" placeholder="Description">
        <input type="text" class="login-input" name="product_img" placeholder="Product Image URL">
        <input type="submit" name="submit" value="Add" class="login-button">
        <p class="link"><a href="products.php">Click to Return to Products</a></p>
    </form>
    <?php
}
?>
</body>
</html>