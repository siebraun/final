<?php
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
$page_title = "Update product details";

require_once ('includes/header.php');
require('includes/database.php');

//retrieve, sanitize, and escape all fields from the form
$product_name = $conn->real_escape_string(trim(filter_input(INPUT_GET, 'product_name', FILTER_SANITIZE_STRING)));
$allergens = $conn->real_escape_string(trim(filter_input(INPUT_GET, 'allergens', FILTER_SANITIZE_STRING)));
$price = $conn->real_escape_string(trim(filter_input(INPUT_GET, 'price', FILTER_SANITIZE_NUMBER_INT)));
$description = $conn->real_escape_string(trim(filter_input(INPUT_GET, 'description', FILTER_SANITIZE_STRING)));
$product_img = $conn->real_escape_string(trim(filter_input(INPUT_GET, 'product_img', FILTER_SANITIZE_STRING)));

//define MySQL update statement
$sql = "UPDATE products SET
product_name='$product_name';
allergens='$allergens';
price='$price';
description='$description';
product_img='$product_img', WHERE product_id = $product_id";


//execute the query
$query = @$conn->query($sql);


//Handle selection errors
if (!$query) {
    $errno = $conn->errno;
    $errmsg = $conn->error;
    echo "Connection Failed with: $errno, $errmsg<br/>\n";
    include ('includes/footer.php');
    exit;
}
echo "This product has been updated.";

// close the connection.
$conn->close();

include ('includes/footer.php');