<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link type="text/css" rel="stylesheet" href="www/chateaudough.css"/>
</head>
<!-- navigation bar -->
<div id="navbar">
    <a href="index.php">Home</a> || <a href="products.php">Our Pastries</a> || <a href="allergens.php">Allergens</a>
    || <a href="login.php">Log In</a>
</div>
<!-- styles -->
<style type="text/css">
    body {
        font: 16px SansSerif;
        align-content: center;
        text-align: 50%;
    }
    .wrapper {
        width: 400px;
        padding: 20px;
    }
</style>
</head>
<body>
<div class="wrapper">
    <h2>Login</h2>
    <p>See our newest deals!</p>
<!-- username and password / sign up -->
<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
<div class="form-group <?php echo (empty($username_err)) ? 'has-error' : ''; ?>">
            <label>Username</label>
            <input type="text" name="username" class="form-control" value="<?php echo $username; ?>">
            <span class="help-block"><?php echo $username_err; ?></span>
</div>
<div class="form-group <?php echo (empty($password_err)) ? 'has-error' : ''; ?>">
            <label>Password</label>
            <input type="password" name="password" class="form-control">
            <span class="help-block"><?php echo $password_err; ?></span>
</div>
<div class="form-group">
            <input type="submit" class="btn btn-primary" value="Login">
</div>
        <p>Not a user? <br> <a href="register.php">Sign up now</a>.</p>
    </form>
</div>
</body>
</html>