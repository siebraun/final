<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <title>Shopping Cart</title>

   <?php require ('includes/header.php'); ?>
</head>
<body>
<p>Check out</p>



<br> <p>Until Next Time!</p>
</body>
<?php
$bodyColor = "#8EC1CC";
require ('includes/footer.php');
?>
</html>