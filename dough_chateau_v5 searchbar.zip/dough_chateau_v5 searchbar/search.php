<?php
/**
 * Author: Group 6
 * Date: 12/7/20
 * File: search.php
 * Description: search bar
 */


require 'includes/header.php';
require_once('includes/database.php');

if(filter_has_var(INPUT_GET, "terms")){
    //retrieve the search term
    $term = filter_input(INPUT_GET,"terms", FILTER_SANITIZE_STRING);
} else {
    echo "There was no search terms(s) found.";
    exit;
}

//explode the search terms into an array
$terms = explode(" ", $term);

$sql = "SELECT * FROM products WHERE";
foreach($terms as $termarray){
    $sql .= " title LIKE '%$termarray%' AND";
}
$sql = rtrim($sql, " AND");
//execute the query
$query = $conn->query($sql);

//Handle errors
if (!$query) {
    $errno = $conn->errno;
    $error = $conn->error;
    $conn->close();
    die("Selection failed: ($errno) $error.");
}
echo "<h2>Products: $term</h2>";

if ($query->num_rows == 0) {
    echo "Your search term: $term did not match our inventory";
    exit;
}
?>
