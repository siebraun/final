<?php
if(session_status()==PHP_SESSION_NONE) {
    session_start();
}

$count=0;

//retrieve cart content
if(isset($_SESSION['cart'])){
    $cart = $_SESSION['cart'];

    if ($cart) {
        $count =array_sum($cart);
    }
}

//set shopping cart image
$shoppingcart_img= 'shoppingcart.png';
?>

<!Doctype html>
<html lang="en">
<head>

    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Chateau Dough</title>
    <link type="text/css" rel="stylesheet" href="css/styles.css"/>
</head>

<div id="navbar">
    <img style="width: 5%; float: left;" src="img/chateau_dough_logo1.PNG" alt="Chateau Dough">
    <h1 class="logoText" style="float: left;"> CHATEAU DOUGH </h1>
    <a class="navText" href="showcart.php">
        <img src="img/shoppingcart.png" style="border:none;width:40px;margin-top: -10px; "/>
    </a>
    <a class="navText" href="login.php">Log In</a>
    <a class="navText" href="allergens.php">Allergens</a>
    <a class="navText" href="products.php">Our Pastries</a>
    <a class="navText" href="index.php">Home </a>
<!--    <input class="search" text placeholder = "search">-->
    <form action="searchresults.php" method="get">
        <input type="text" name="terms" size="40" required />&nbsp;&nbsp;
        <input type="submit" name="Submit" id="Submit" value="Search" />
    </form>
</div>
