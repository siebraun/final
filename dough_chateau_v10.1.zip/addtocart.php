<?php

if(session_status()==PHP_SESSION_NONE) {
    session_start();
}

if(isset($_SESSION['cart'])){
    $cart=$_SESSION['cart'];
} else {
    $cart=array();
}

//ifbookidcannotbefound,terminatescript.
if(!filter_has_var(INPUT_GET,'id')){
    $error="Bookidnotfound.Operationcannotproceed.<br><br>";
    header("Location:error.php?m=$error");
    die();
}
//retrieve book id and make sure it is a numeric value.
$id=filter_input(INPUT_GET,'id',FILTER_SANITIZE_NUMBER_INT);
if(!is_numeric($id)){
    $error="Invalidbookid.Operationcannotproceed.<br><br>";
    header("Location:error.php?m=$error");
    die();
}

//update the session variable
$_SESSION['cart']=$cart;

//redirect to the showcart.phppage.
header('Location:showcart.php');