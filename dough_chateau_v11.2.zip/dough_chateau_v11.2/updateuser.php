<?php
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
$page_title = "Update user details";

require_once ('includes/header.php');
require('includes/database.php');

//retrieve, sanitize, and escape all fields from the form
$user_id = $conn->real_escape_string(trim(filter_input(INPUT_GET, 'id', FILTER_SANITIZE_NUMBER_INT)));
$username = $conn->real_escape_string(trim(filter_input(INPUT_GET, 'username', FILTER_SANITIZE_STRING)));
$password = $conn->real_escape_string(trim(filter_input(INPUT_GET, 'password', FILTER_SANITIZE_STRING)));
$email = $conn->real_escape_string(trim(filter_input(INPUT_GET, 'email', FILTER_SANITIZE_EMAIL)));

//define MySQL update statement
$sql = "UPDATE users SET
username='$username';
password='$password';
email='$email', WHERE user_id = $id";


//execute the query
$query = @$conn->query($sql);


//Handle selection errors
if (!$query) {
    $errno = $conn->errno;
    $errmsg = $conn->error;
    echo "Connection Failed with: $errno, $errmsg<br/>\n";
    include ('includes/footer.php');
    exit;
}
echo "Your account has been updated.";

// close the connection.
$conn->close();

include ('includes/footer.php');