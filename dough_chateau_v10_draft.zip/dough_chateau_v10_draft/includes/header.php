<?php>
if(session_status()==PHP_SESSION_NONE)
{session_start();
}

$count=0;

//retrieve cart content
if(isset($_SESSION['cart'])){
    $cart=$_SESSION['cart'];
if($cart){
    $count=array_sum($cart);
    }
}

//set shopping cart image
$shoppingcart_img=(!$count)?"shoppingcart_empty.gif":"shoppingcart_full.gif";

<?>

<!Doctype html>
<html lang="en">
<head>

    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Chateau Dough</title>
    <link type="text/css" rel="stylesheet" href="css/styles.css"/>
</head>

<div id="navbar">
    <img style="width: 5%; float: left;" src="img/chateau_dough_logo1.PNG" alt="Chateau Dough">
    <h1 class="logoText" style="float: left;"> CHATEAU DOUGH </h1>
    <a href="showcart.php">
    <img src="www/img/<?=$shoppingcart_img?>" style="border:none;width:50px"/>
    <br/>
    <span><?phpecho$count?>item(s)</span>
    </a>
    <a class="navText" href="login.php">Log In</a>
    <a class="navText" href="allergens.php">Allergens</a>
    <a class="navText" href="products.php">Our Pastries</a>
    <a class="navText" href="index.php">Home </a>
</div>
