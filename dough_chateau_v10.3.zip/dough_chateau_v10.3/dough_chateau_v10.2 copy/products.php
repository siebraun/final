<?php
require 'includes/header.php';
require_once 'includes/database.php';

$sql = "SELECT * FROM products";

//execute the query
$query = $conn->query($sql);

//retrieve results
$row = $query->fetch_assoc();


if (!$query) {
    $errno = $conn->errno;
    $errmsg = $conn->error;
    echo "Selection failed with: ($errno) $errmsg<br/>\n";
    $conn->close();
    require_once('includes/footer.php');
    exit;

    $result = $conn->query($sql) or die($conn->error);
}
?>

<!-- body -->
<body>

<div style="width: 70%" class="productTableDiv">
    <table id="productTableBig" class="productTableBig">
    <tr>
        <th></th>
        <th class="col2"></th>
        <th class="col3"></th>

    </tr>

    <!-- book data -->
    <?php
    while(($row = $query->fetch_assoc()) !==NULL){
        echo "<tr>"; ?>

        <td> <img width="150px" src=" <?php echo $row['product_img']?>"/></td>
<?php   echo "<td><a href=product_details.php?id=", $row["product_id"], ">", $row["product_name"], "</td>";
        echo "<td>", $row['price'], "</td>";
    }
    ?>
    </table>

    <a href="newproduct.php">Add product</a>
</div>


</body>
</html>