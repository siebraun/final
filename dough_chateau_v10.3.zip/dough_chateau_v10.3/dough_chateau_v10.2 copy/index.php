
<!doctype html>
<html lang="en">
<head>

    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Chateau Dough</title>
    <link type="text/css" rel="stylesheet" href="css/styles.css"/>
</head>

<body style="background-image: url('img/heroimg.jpg'); background-size: cover;">
<?php
require ('includes/header.php');
?>



<div class="wrapper">
<header>
    <p style="font-size: 65px;" class="header1"> Vegan sweets fit for <p> <p style="font-size: 75px;" class="header2"> royalty <p>
</header>

</div>


</body>
</html>
<?php
require ('includes/footer.php');