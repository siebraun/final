<?php


$page_title = "Edit Product Details";

require_once ('includes/header.php');
require_once ('includes/database.php');

if (!filter_has_var(INPUT_GET, 'id')){
    echo "error: book id was not found.";
    exit();
}
$product_id = filter_input(INPUT_GET, 'id', FILTER_SANITIZE_NUMBER_INT);
$sql = "SELECT * FROM products WHERE product_id=$product_id";


//execute query
$query = $conn->query($sql);
//retrieve results
$row = $query->fetch_assoc();



//Handle selection errors
if (!$query) {
    $errno = $conn->errno;
    $errmsg = $conn->error;
    echo "Selection failed with: ($errno) $errmsg<br/>\n";
    $conn->close();
    //include the footer
    require_once ('includes/header.php');
    exit;
}
//display results in a table in the below HTML block
?>

    <h2>Edit product</h2>

    <form name="editproduct" action="updateproduct.php" method="get">
        <table class="productdetails">
            <tr>
                <th>Product Name</th>
                <td><input name="name" value="<?php echo $row['product_name'] ?>" size="30" required /></td>
            </tr>
            <tr>
                <th>Allergens</th>
                <td><input name="allergens" value="<?php echo $row['allergens'] ?>" size="30" required /></td>
            </tr>
            <tr>
                <th>Price</th>
                <td><input name="price" value="<?php echo $row['price'] ?>" size="40" required /></td>
            </tr>
            <tr>
                <th>Description</th>
                <td><input name="description" value="<?php echo $row['description'] ?>" size="150" required /></td>
            </tr>
            <tr>
                <th>Product Image</th>
                <td><input name="product_img" value="<?php echo $row['product_img'] ?>" size="30" required /></td>
            </tr>
        </table>
    </form>
    <br>
    <input type="submit" value="Update">
    <input type="button" onclick="window.location.href='product_details.php?id=<?php echo $row['product_id'] ?>'" value="Cancel">

<?php
// clean up resultsets when we're done with them!
$query->close();

// close the connection.
$conn->close();

//include the footer
require_once ('includes/footer.php');
?>