<?php
if(session_status()==PHP_SESSION_NONE) {
    session_start();
}

$count=0;

//retrieve cart content
if(isset($_SESSION['cart'])){
    $cart = $_SESSION['cart'];

    if ($cart) {
        $count =array_sum($cart);
    }
}

//set shopping cart image
$shoppingcart_img= 'shoppingcart.png';

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

$count=0;

if (isset($_SESSION['cart'])) {
    $cart = $_SESSION['cart'];

    if ($cart) {
        $count = array_sum($cart);
    }
}

$login='';
$name='';
$role=0;


//if the user has logged in, retrieve login, name, and role.
if (isset($_SESSION['login']) AND isset($_SESSION['name']) AND isset($_SESSION['role'])) {
    $login = $_SESSION['login'];
    $name = $_SESSION['name'];
    $role = $_SESSION['role'];
}



?>
<!Doctype html>
<html lang="en">
<head>

    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Chateau Dough</title>
    <link type="text/css" rel="stylesheet" href="css/styles.css"/>
</head>

<div id="navbar">
    <img style="width: 5%; float: left;" src="img/chateau_dough_logo1.PNG" alt="Chateau Dough">
    <h1 class="logoText" style="float: left;"> CHATEAU DOUGH </h1>
    <a class="navText" href="showcart.php">
        <img src="img/shoppingcart.png" style="border:none;width:40px;margin-top: -10px; "/>
    </a>


    <!--nav links -->
    <?php
    if ($role == 1){
        echo "<a class='navText' href='userdetails.php'>Users</a>";}

    if (empty($login))
        echo "<a class='navText' href = 'loginform.php'>Login</a>";
    else {echo "<a class='navText' href = 'logout.php'>Logout</a>";
        echo "<span style = 'color:red; margin‐left:30px'>Welcome $name !</span>";
    }
?>
    <a class="navText" href="allergens.php">Allergens</a>
    <a class="navText" href="products.php">Our Pastries</a>
    <a class="navText" href="index.php">Home </a>
</div>

<!--search bar -->
<div class="searchWrapper">
<form class="searchBar"  action="searchresults.php" method="get">
    <input class="searchText" type="text" name="terms" size="40" required />&nbsp;&nbsp;
    <input class="Button" type="submit" name="Submit" id="Submit" value="Search" />
</form>
</div>