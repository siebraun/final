<?php
$page_title = "Product Details";
require_once ('includes/header.php');
require_once ('includes/database.php');




//retrieve product id
if (!filter_has_var(INPUT_GET, 'id')){
    echo "error: product id was not found.";
    exit();
}
$product_id = filter_input(INPUT_GET, 'id', FILTER_SANITIZE_NUMBER_INT);
$sql = "SELECT * FROM products WHERE product_id=$product_id";

//execute the query
$query = $conn->query($sql);

//retrieve results
$row = $query->fetch_assoc();


?>

<!doctype html>
<html lang="en"
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Products</title>
    <link type="text/css" rel="stylesheet" href="www/chateaudough.css" />
</head>


<div class="productdetailsWrapper">
<h2> Products</h2>
<table id="product_details" class="product_details">


    <tr>
        <td class="col1">
            <img class="productPhoto" src=" <?php echo $row['product_img']?>"/>
        </td>
        <td class="col2">
            <h4></h4>
            <h4></h4>
            <h4></h4>
            <h4></h4>
        </td>
        <td style="background-color: whitesmoke; padding: 20px;" class="col3">
            <p style="font-weight: bold; font-size: 26px; margin-top: -10px;" ><?php echo $row['product_name'] ?></p>
            <p>$<?php echo $row['price'] ?></p>
            <p>Allergens: <?php echo $row['allergens'] ?></p>
            <p><?php echo $row['description'] ?></p>
        </td>
    </tr>

</table>

    <p class="productDetailsButtons">
        <a href="editproduct.php?id=<?php echo $row['product_id'] ?>">Edit</a>
        <a href="deleteproduct.php?id=<?php echo $row['product_id'] ?>">Delete</a>
        <a href="addtocart.php?id=<?php echo $row['product_id'] ?>">Add to Cart</a>
    </p>

</div>

</body>
</html>